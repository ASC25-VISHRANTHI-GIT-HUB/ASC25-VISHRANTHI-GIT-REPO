package com.labs.lab2.ps1;

public class ZoomMeetingRoom extends  MeetingRoom {
   private String deviceId;
   private String accountId;
}
