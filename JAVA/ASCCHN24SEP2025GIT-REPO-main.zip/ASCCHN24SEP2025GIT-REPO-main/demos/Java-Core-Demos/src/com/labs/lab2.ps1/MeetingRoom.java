package com.labs.lab2.ps1;

public class MeetingRoom {
    private String meetingRoomId;
    // The range of byte is from -128 to 127, so we can use it for small capacity values.
    private byte capacity;
    private String floorLocation;

    
}
