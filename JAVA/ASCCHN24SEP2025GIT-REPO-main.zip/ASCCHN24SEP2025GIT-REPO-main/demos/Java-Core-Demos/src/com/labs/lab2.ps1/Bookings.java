// package com.labs.lab2.ps1;

// public class Bookings {
//     private String bookingDate;
//     private Booking[] bookings;
// }
