package com.demo.check;

public class ArrayIndexOutOfBoundsException
{
    public static void main(String args[])
    {
        int []arr = {1,2,3,4,5};
        System.out.println(arr[5]);
    }
}
