package com.demo.inheritance;

public class IsARelationship {

}

class Book {
//	has -a
	Page page;
	Page pages[];
}

// is-a
class Kindle extends Book {

}

class Page {

}
