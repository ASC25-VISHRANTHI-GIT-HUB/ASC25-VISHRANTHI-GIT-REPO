package com.demo.exceptions;
class Calculator1 {
    public static void add(int num1, int num2) {
        System.out.println(num1 + num2);
    }
}