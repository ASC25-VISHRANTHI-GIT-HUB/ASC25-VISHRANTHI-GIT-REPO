package com.demo.inheritance;

//public class FinalClass {
//
//}

final class FC {

}

//final class FC5 extends FC {
//
//}


//class ClassA {
//
//}

//final class FC6 extends ClassA {
//
//}
//class FC1 extends FC {
//
//}

// class FC {
//	 final void m() {
//		 
//	 }
//}
//
//class FC1 extends FC {
////	Cannot override the final method from FC
//	 final void m() {
//		 
//	 }
//}
