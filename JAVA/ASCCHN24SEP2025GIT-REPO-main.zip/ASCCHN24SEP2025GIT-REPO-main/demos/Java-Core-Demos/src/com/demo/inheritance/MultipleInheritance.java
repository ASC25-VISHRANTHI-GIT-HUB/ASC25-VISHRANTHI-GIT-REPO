package com.demo.inheritance;

public class MultipleInheritance {

}


class A50 {
	
}
class A51 {
	
}

// multiple inheritance not supported.
//class A52 extends A50, A51 {
//
//}


// we can use multiple interfaces (OPPOSITE alternate)
// tea, green tea (tea)
// train , plane (alternate)
// (is a) inheritance has a relationship, interfaces do not have a relationship 
// Cat is a Animal. Dog is an Animal.
// Bird flies (Flyer), Plane (Flyer) [CONTRACT]. Interfaces are contracts.

// PLANE EXTENDS ANIMAL (WRONG)
// PLANE IMPLEMENTS FLYER (PERFECT)
// BIRD IMPLEMENTS FLYER (PERECT)

// FLYER fly(), land() 