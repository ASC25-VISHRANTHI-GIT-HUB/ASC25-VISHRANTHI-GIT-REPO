package com.demo.funda;

public class App {
    public static void main(String[] args) {
        System.out.println("Welcome to the world of Java!");
    }
}
